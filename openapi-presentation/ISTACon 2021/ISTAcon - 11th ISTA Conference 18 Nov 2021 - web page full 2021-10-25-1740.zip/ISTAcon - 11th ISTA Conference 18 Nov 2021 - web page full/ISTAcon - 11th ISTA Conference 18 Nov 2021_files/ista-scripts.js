// ------------------------------------------------------------------------
// Custom Ista Scripts
// ------------------------------------------------------------------------
function allScripts() {
  // Tabs Agenda Section
  let tabButtons = document.querySelectorAll(
    ".row--tab-controls .tab-controls-item"
  );
  let tabContainers = document.querySelectorAll(".tab-content-container");

  for (let index = 0; index < tabButtons.length; index++) {
    const currentButton = tabButtons[index];
    const currentContainer = tabContainers[index];

    currentButton.onclick = function () {
      const activeButton = document.querySelector(
        ".row--tab-controls .tab-controls-item.active"
      );
      const activeContainer = document.querySelector(
        ".tab-content-container.active"
      );

      // Animate the Pill
      activeButton.classList.remove("active");
      currentButton.classList.add("active");

      // Swtich Tabs
      activeContainer.classList.remove("active");
      currentContainer.classList.add("active");
    };
  }

  // Click on View All to show more;
  let viewAllBtn = document.querySelector(".view-all-btn");
  let speakersContainer = document.querySelector(".speaker-badges-container");

  viewAllBtn.addEventListener("click", function () {
    if (speakersContainer.classList.contains("show-all")) {
      speakersContainer.classList.remove("show-all");
      viewAllBtn.innerHTML = "View All";
    } else {
      speakersContainer.classList.add("show-all");
      viewAllBtn.innerHTML = "Hide";
    }
  });

  // Mobile Nav Button
  let navButton = document.querySelector(".mobile-menu-btn");
  let mainNav = document.querySelector(".main-nav");
  let mainNavLink = document.querySelectorAll(".main-nav .nav-item");
  navButton.addEventListener("click", () => {
    navButton.classList.toggle("active");
    mainNav.classList.toggle("mobile-visible");
  });

  mainNavLink.forEach((element) => {
    element.addEventListener("click", () => {
      navButton.classList.remove("active");
      mainNav.classList.remove("mobile-visible");
    });
  });

  // Gallery Scripts
  const swiperGalleryThumbs = new Swiper(".swiper-container--gallery-thumbs", {
    loop: false,
    cssMode: true,
    spaceBetween: 16,
    slidesPerView: 7,
  });
  const swiperGallery = new Swiper(".swiper-container--gallery", {
    loop: true,
    navigation: {
      nextEl: ".swiper-nav-next",
      prevEl: ".swiper-nav-prev",
    },
    thumbs: {
      swiper: swiperGalleryThumbs,
    },
  });

  /// anchor tag + 70px because of header
  let navAnchorBtns = document.querySelectorAll(".nav-item");
  function offsetAnchor() {
    if (location.hash.length !== 0) {
      window.scrollTo(window.scrollX, window.scrollY - 70);
    }
  }

  navAnchorBtns.forEach((navItem) => {
    navItem.addEventListener("click", function (event) {
      window.setTimeout(function () {
        offsetAnchor();
      }, 0);
    });
  });

  // Set the offset when entering page with hash present in the url
  window.setTimeout(offsetAnchor, 0);

  // Partners Banners SwiperJS init
  let slidesLength = document.querySelectorAll(".swiper-slide").length;
  let randomInitialSlide = Math.floor(Math.random() * slidesLength);
  const swiperPartnerBanners = new Swiper(".swiper-container--partners", {
    loop: true,
    initialSlide: randomInitialSlide,
    pagination: {
      el: ".swiper-pagination",
      clickable: true,
      dynamicBullets: true,
    },
    autoplay: {
      delay: 3000,
      pauseOnMouseEnter: true,
    },
    // Disable preloading of all images
    preloadImages: false,
    // Enable lazy loading
    lazy: true,
  });
}

// Vanilla JS alternative to $(document).ready
if (
  document.attachEvent
    ? document.readyState === "complete"
    : document.readyState !== "loading"
) {
  allScripts();
} else {
  document.addEventListener("DOMContentLoaded", allScripts);
}
