jQuery(document).ready(function ($) {
  var simpleEventLink = $(".simple-event > a");
  var agendaEntryLink = $(".agenda-entry > a");
  var modalWrapper = $(".agenda-modal");
  var modalWrapperBox = $(".agenda-modal .agenda-modal-box");
  var modalWrapperTitle = $(".agenda-modal .agenda-modal-content .title");
  var modalWrapperText = $(".agenda-modal .agenda-modal-content .text");

  $(simpleEventLink)
    .add(agendaEntryLink)
    .click(function (e) {
      var modalTitle = $(this).text();
      var modalText = $(this).next().html();

      e.preventDefault();

      //   $(".home").css("overflow", "hidden");

      modalWrapperTitle.html(modalTitle);
      modalWrapperText.html(modalText);
      modalWrapper.css("display", "flex");
      modalWrapper.addClass("show");
    });

  $(".agenda-modal-close").click(function (e) {
    // $(".home").css("overflow", "visible");
    modalWrapper.removeClass("show");
    modalWrapper.css("display", "none");
  });

  $(document).mouseup(function (e) {
    if (
      !modalWrapperBox.is(e.target) &&
      modalWrapperBox.has(e.target).length === 0
    ) {
      //   $(".home").css("overflow", "visible");
      modalWrapper.removeClass("show");
      modalWrapper.css("display", "none");
    }
  });
});
